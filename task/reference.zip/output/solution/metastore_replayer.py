from __future__ import annotations

import csv
import json
from pathlib import Path

import airflow
import pendulum
from airflow.models.dag import DAG, DagModel
from airflow.models.dagrun import DagRun
from airflow.models.log import Log
from airflow.serialization.serialized_objects import SerializedDAG
from airflow.utils.session import create_session
from airflow.utils.state import DagRunState
from airflow.utils.types import DagRunType


EVENT_FIELDS = [
    "sequence",
    "event_type",
    "event_id",
    "logical_date",
    "run_state",
    "operator_note",
    "trailing_failures",
    "is_paused",
    "pause_event_delta",
    "verdict",
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def trailing_failure_count(session, dag_id: str) -> int:
    states = [
        row.state
        for row in session.query(DagRun)
        .filter(DagRun.dag_id == dag_id)
        .order_by(DagRun.execution_date.desc())
        .all()
    ]
    count = 0
    for state in states:
        if state != DagRunState.FAILED:
            break
        count += 1
    return count


def pause_log_count(session, dag_id: str) -> int:
    return (
        session.query(Log)
        .filter(Log.dag_id == dag_id, Log.event == "paused")
        .count()
    )


def expected_trajectory(
    events: list[dict[str, str]], threshold: int
) -> dict[str, dict[str, int | str]]:
    history: list[tuple[pendulum.DateTime, str]] = []
    paused = False
    expected: dict[str, dict[str, int | str]] = {}
    for event in sorted(events, key=lambda row: int(row["sequence"])):
        before_states = [state for _, state in sorted(history, reverse=True)]
        before_streak = 0
        for state in before_states:
            if state != "failed":
                break
            before_streak += 1
        before_paused = paused
        pause_delta = 0
        if event["event_type"] == "DAGRUN":
            history.append((pendulum.parse(event["logical_date"]), event["run_state"]))
            states = [state for _, state in sorted(history, reverse=True)]
            streak = 0
            for state in states:
                if state != "failed":
                    break
                streak += 1
            if event["run_state"] == "failed" and streak >= threshold:
                paused = True
                pause_delta = 1
            if event["run_state"] == "success":
                verdict = "SUCCESS_RESET" if before_streak else "SUCCESS_BASELINE"
            elif pause_delta and before_streak >= threshold and not before_paused:
                verdict = "REPAUSE_AFTER_UNPAUSE"
            elif pause_delta:
                verdict = "THRESHOLD_PAUSE"
            else:
                verdict = f"FAILURE_STREAK_{streak}"
        else:
            states = [state for _, state in sorted(history, reverse=True)]
            streak = 0
            for state in states:
                if state != "failed":
                    break
                streak += 1
            paused = False
            verdict = (
                "ADMIN_UNPAUSE_HISTORY_RETAINED"
                if streak >= threshold
                else "ADMIN_UNPAUSE"
            )
        expected[event["event_id"]] = {
            "trailing_failures": streak,
            "is_paused": str(paused).lower(),
            "pause_event_delta": pause_delta,
            "verdict": verdict,
        }
    return expected


def replay(
    dag: DAG,
    policy: dict,
    events: list[dict[str, str]],
    output_root: Path,
) -> dict:
    DAG.bulk_write_to_db({dag})
    threshold = int(policy["max_consecutive_failed_dag_runs"])
    expected = expected_trajectory(events, threshold)
    event_rows: list[dict] = []

    with create_session() as session:
        model = DagModel.get_dagmodel(dag.dag_id, session=session)
        if model is None:
            raise RuntimeError("DAG was not synchronized into DagModel")
        for event in sorted(events, key=lambda row: int(row["sequence"])):
            before_streak = trailing_failure_count(session, dag.dag_id)
            before_paused = bool(model.is_paused)
            before_logs = pause_log_count(session, dag.dag_id)
            if event["event_type"] == "DAGRUN":
                logical_date = pendulum.parse(event["logical_date"])
                state = DagRunState(event["run_state"])
                dagrun = DagRun(
                    dag_id=dag.dag_id,
                    run_id=event["event_id"],
                    execution_date=logical_date,
                    run_type=DagRunType.MANUAL,
                    state=state,
                    external_trigger=True,
                    data_interval=(logical_date, logical_date.add(days=1)),
                )
                session.add(dagrun)
                session.flush()
                if state == DagRunState.FAILED:
                    dagrun._check_last_n_dagruns_failed(
                        dag.dag_id, threshold, session
                    )
            elif event["event_type"] == "ADMIN_UNPAUSE":
                model = DagModel.get_dagmodel(dag.dag_id, session=session)
                model.set_is_paused(False, session=session)
            else:
                raise ValueError(f"unsupported event_type: {event['event_type']}")

            session.flush()
            session.expire_all()
            model = DagModel.get_dagmodel(dag.dag_id, session=session)
            after_streak = trailing_failure_count(session, dag.dag_id)
            pause_delta = pause_log_count(session, dag.dag_id) - before_logs
            if event["event_type"] == "ADMIN_UNPAUSE":
                verdict = (
                    "ADMIN_UNPAUSE_HISTORY_RETAINED"
                    if after_streak >= threshold
                    else "ADMIN_UNPAUSE"
                )
            elif event["run_state"] == "success":
                verdict = "SUCCESS_RESET" if before_streak else "SUCCESS_BASELINE"
            elif pause_delta and before_streak >= threshold and not before_paused:
                verdict = "REPAUSE_AFTER_UNPAUSE"
            elif pause_delta:
                verdict = "THRESHOLD_PAUSE"
            else:
                verdict = f"FAILURE_STREAK_{after_streak}"
            event_rows.append(
                {
                    "sequence": int(event["sequence"]),
                    "event_type": event["event_type"],
                    "event_id": event["event_id"],
                    "logical_date": event["logical_date"],
                    "run_state": event["run_state"],
                    "operator_note": event["operator_note"],
                    "trailing_failures": after_streak,
                    "is_paused": str(bool(model.is_paused)).lower(),
                    "pause_event_delta": pause_delta,
                    "verdict": verdict,
                }
            )

        run_rows = [
            {
                "run_id": row.run_id,
                "logical_date": row.execution_date.isoformat().replace("+00:00", "Z"),
                "state": str(row.state),
                "run_type": str(row.run_type),
                "external_trigger": str(bool(row.external_trigger)).lower(),
            }
            for row in session.query(DagRun)
            .filter(DagRun.dag_id == dag.dag_id)
            .order_by(DagRun.execution_date)
            .all()
        ]
        pause_rows = [
            {
                "ordinal": index,
                "event": row.event,
                "dag_id": row.dag_id,
                "owner": row.owner,
                "owner_display_name": row.owner_display_name,
                "extra": row.extra,
            }
            for index, row in enumerate(
                session.query(Log)
                .filter(Log.dag_id == dag.dag_id, Log.event == "paused")
                .order_by(Log.id)
                .all(),
                1,
            )
        ]
        model = DagModel.get_dagmodel(dag.dag_id, session=session)
        model_snapshot = {
            "dag_id": model.dag_id,
            "is_paused": bool(model.is_paused),
            "is_active": bool(model.is_active),
            "schedule_interval": model.schedule_interval,
            "max_active_runs": model.max_active_runs,
            "max_consecutive_failed_dag_runs": model.max_consecutive_failed_dag_runs,
            "owners": model.owners,
        }

    serialized = SerializedDAG.to_dict(dag)
    serialized["dag"]["fileloc"] = "output/dags/moderation_feed_publish_guard.py"
    serialized["dag"]["_processor_dags_folder"] = "output/dags"
    event_by_id = {row["event_id"]: row for row in event_rows}
    input_runs = [row for row in events if row["event_type"] == "DAGRUN"]
    expected_states = {row["event_id"]: row["run_state"] for row in input_runs}
    actual_states = {row["run_id"]: row["state"] for row in run_rows}
    tasks = sorted(dag.task_ids)
    edges = sorted(
        (task.task_id, downstream_id)
        for task in dag.tasks
        for downstream_id in task.downstream_task_ids
    )
    expected_edges = sorted(tuple(edge) for edge in policy["expected_edges"])
    projected = {
        row["event_id"]: {
            key: str(row[key])
            for key in (
                "sequence",
                "event_type",
                "logical_date",
                "run_state",
                "operator_note",
            )
        }
        for row in event_rows
    }
    source_projection = {
        row["event_id"]: {
            key: row[key]
            for key in (
                "sequence",
                "event_type",
                "logical_date",
                "run_state",
                "operator_note",
            )
        }
        for row in events
    }
    trajectory_matches = all(
        all(event_by_id[event_id][key] == value for key, value in values.items())
        for event_id, values in expected.items()
    )
    pause_extra = f"[('dag_id', '{dag.dag_id}'), ('is_paused', True)]"
    checks = {
        "starter_repaired_into_policy_bound_dag": (
            dag.max_consecutive_failed_dag_runs
            == model_snapshot["max_consecutive_failed_dag_runs"]
            == serialized["dag"]["max_consecutive_failed_dag_runs"]
            == threshold
        ),
        "task_graph_matches_policy": (
            tasks == sorted(policy["expected_tasks"])
            and edges == expected_edges
        ),
        "schedule_controls_match_policy": (
            str(dag.schedule_interval) == policy["schedule"]
            and dag.catchup is policy["catchup"]
            and dag.max_active_runs == policy["max_active_runs"]
            and dag.is_paused_upon_creation is policy["is_paused_upon_creation"]
        ),
        "ledger_preserves_input_projection": projected == source_projection,
        "airflow_trajectory_matches_policy_simulation": trajectory_matches,
        "dagrun_rows_match_input": actual_states == expected_states,
        "dagrun_attributes_are_real_manual_triggers": (
            len(run_rows) == len(input_runs)
            and all(
                row["run_type"] == policy["run_type"]
                and row["external_trigger"] == "true"
                for row in run_rows
            )
        ),
        "paused_audit_rows_are_airflow_method_rows": (
            len(pause_rows)
            == sum(int(row["pause_event_delta"]) for row in event_rows)
            and all(
                row["event"] == "paused"
                and row["dag_id"] == dag.dag_id
                and row["owner"] == "scheduler"
                and row["owner_display_name"] == "Scheduler"
                and row["extra"] == pause_extra
                for row in pause_rows
            )
        ),
        "final_state_matches_last_event": (
            model_snapshot["is_paused"]
            == (event_rows[-1]["is_paused"] == "true")
        ),
    }

    write_csv(output_root / "event_ledger.csv", EVENT_FIELDS, event_rows)
    write_csv(
        output_root / "dagrun_history.csv",
        ["run_id", "logical_date", "state", "run_type", "external_trigger"],
        run_rows,
    )
    write_csv(
        output_root / "pause_log.csv",
        ["ordinal", "event", "dag_id", "owner", "owner_display_name", "extra"],
        pause_rows,
    )
    (output_root / "dag_model_snapshot.json").write_text(
        json.dumps(model_snapshot, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (output_root / "serialized_dag.json").write_text(
        json.dumps(serialized, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    validation = {
        "airflow_version": airflow.__version__,
        "controls": {
            "event_rows": len(event_rows),
            "dagrun_rows": len(run_rows),
            "pause_log_rows": len(pause_rows),
            "success_runs": sum(row["state"] == "success" for row in run_rows),
            "failed_runs": sum(row["state"] == "failed" for row in run_rows),
            "threshold_from_policy": threshold,
            "final_trailing_failures": event_rows[-1]["trailing_failures"],
            "final_is_paused": model_snapshot["is_paused"],
        },
        "checks": checks,
        "result": "PASS" if checks and all(checks.values()) else "FAIL",
    }
    (output_root / "validation.json").write_text(
        json.dumps(validation, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return validation
