#内容审核Feed连续失败保护参考实现

将两个压缩包解压到同一工作目录，使`input_data/`与`output/`并列。为每次重建准备新的`AIRFLOW_HOME`，执行`airflow db migrate`，再运行`python output/tools/run_reference.py`。也可通过`ALE_INPUT_ROOT`与`ALE_OUTPUT_ROOT`指定输入和结果目录。

Windows复现使用Windows11或Windows Server2025主机启用WSL2，在Ubuntu24.04内安装Airflow2.10.5并设置SequentialExecutor。输入包和交付源码不含ELF、共享库或Shell脚本等Linux中间产物；安装完成后，迁移、重放和测试均可断网完成。

运行器先解析`input_data/starter/broken_moderation_feed.py`，确认缺陷确为阈值0，再解析修复后的`output/dags/moderation_feed_publish_guard.py`。策略值在DAG对象、DagModel和SerializedDAG三个表示层必须一致。

事件会写入真实DagRun表。failed运行调用Airflow2.10.5的连续失败检查，管理员事件调用DagModel解封。程序没有启动scheduler；`pause_log.csv`中的scheduler所有者字段来自连续失败方法写入的真实Log行。

`validation.json`的checks由本次输入、元数据库行与六份结果重新计算，不固定检查项数量。可用`python output/tests/test_results.py`复核输入投影、状态轨迹、策略绑定和检查日志。不同空库重建按结构化主键与字段值比较，不使用数据库内部日志ID或时间戳作为答案。
