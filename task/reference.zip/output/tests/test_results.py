from __future__ import annotations

import csv
import json
import os
import sys
import unittest
from pathlib import Path


OUTPUT_ROOT = Path(__file__).resolve().parents[1]
INPUT_ROOT = Path(os.environ.get("ALE_INPUT_ROOT", OUTPUT_ROOT.parent / "input_data"))
RESULTS = Path(os.environ.get("ALE_OUTPUT_ROOT", OUTPUT_ROOT / "results"))
sys.path.insert(0, str(OUTPUT_ROOT))
from solution.metastore_replayer import expected_trajectory  # noqa: E402


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


class ResultContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.events = rows(INPUT_ROOT / "incident_timeline.csv")
        cls.policy = json.loads((INPUT_ROOT / "pause_policy.json").read_text(encoding="utf-8"))
        cls.ledger = rows(RESULTS / "event_ledger.csv")
        cls.history = rows(RESULTS / "dagrun_history.csv")
        cls.pause_log = rows(RESULTS / "pause_log.csv")
        cls.snapshot = json.loads((RESULTS / "dag_model_snapshot.json").read_text(encoding="utf-8"))
        cls.serialized = json.loads((RESULTS / "serialized_dag.json").read_text(encoding="utf-8"))["dag"]
        cls.validation = json.loads((RESULTS / "validation.json").read_text(encoding="utf-8"))

    def test_delivery_and_input_projection(self) -> None:
        self.assertEqual(
            {path.name for path in RESULTS.iterdir()},
            {
                "event_ledger.csv",
                "dagrun_history.csv",
                "pause_log.csv",
                "dag_model_snapshot.json",
                "serialized_dag.json",
                "validation.json",
            },
        )
        source = {
            row["event_id"]: tuple(
                row[key]
                for key in (
                    "sequence",
                    "event_type",
                    "logical_date",
                    "run_state",
                    "operator_note",
                )
            )
            for row in self.events
        }
        projected = {
            row["event_id"]: tuple(
                row[key]
                for key in (
                    "sequence",
                    "event_type",
                    "logical_date",
                    "run_state",
                    "operator_note",
                )
            )
            for row in self.ledger
        }
        self.assertEqual(projected, source)

    def test_airflow_state_trajectory(self) -> None:
        expected = expected_trajectory(
            self.events, self.policy["max_consecutive_failed_dag_runs"]
        )
        actual = {row["event_id"]: row for row in self.ledger}
        for event_id, values in expected.items():
            for key, value in values.items():
                self.assertEqual(str(actual[event_id][key]), str(value))

    def test_metastore_views_and_audit(self) -> None:
        input_runs = [row for row in self.events if row["event_type"] == "DAGRUN"]
        self.assertEqual(
            {row["run_id"]: row["state"] for row in self.history},
            {row["event_id"]: row["run_state"] for row in input_runs},
        )
        threshold = self.policy["max_consecutive_failed_dag_runs"]
        self.assertEqual(self.snapshot["max_consecutive_failed_dag_runs"], threshold)
        self.assertEqual(self.serialized["max_consecutive_failed_dag_runs"], threshold)
        self.assertTrue(
            all(
                row["event"] == "paused"
                and row["owner"] == "scheduler"
                and row["owner_display_name"] == "Scheduler"
                for row in self.pause_log
            )
        )

    def test_validation_is_recomputed(self) -> None:
        checks = self.validation["checks"]
        self.assertTrue(checks)
        self.assertTrue(all(checks.values()))
        self.assertEqual(self.validation["result"], "PASS")


if __name__ == "__main__":
    unittest.main(verbosity=2)
