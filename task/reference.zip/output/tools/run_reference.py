from __future__ import annotations

import csv
import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

from airflow.models.dagbag import DagBag


reference_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(reference_root))
from solution.metastore_replayer import replay  # noqa: E402


input_root = Path(
    os.environ.get("ALE_INPUT_ROOT", reference_root.parent / "input_data")
).resolve()
output_root = Path(
    os.environ.get("ALE_OUTPUT_ROOT", reference_root / "results")
).resolve()
stage_root = output_root.parent / f".{output_root.name}.staging-{os.getpid()}"
backup_root = output_root.parent / f".{output_root.name}.backup-{os.getpid()}"


def fail(message: str) -> None:
    raise ValueError(message)


def graph(dag) -> tuple[list[str], list[tuple[str, str]]]:
    tasks = sorted(dag.task_ids)
    edges = sorted(
        (task.task_id, downstream_id)
        for task in dag.tasks
        for downstream_id in task.downstream_task_ids
    )
    return tasks, edges


def read_and_validate_inputs() -> tuple[dict, list[dict[str, str]]]:
    expected_files = {
        "README.md",
        "incident_timeline.csv",
        "pause_policy.json",
        "starter/broken_moderation_feed.py",
    }
    actual_files = {
        path.relative_to(input_root).as_posix()
        for path in input_root.rglob("*")
        if path.is_file()
    }
    if actual_files != expected_files:
        fail(f"input file set mismatch: {sorted(actual_files)}")

    with (input_root / "incident_timeline.csv").open(
        newline="", encoding="utf-8"
    ) as handle:
        reader = csv.DictReader(handle)
        expected_header = [
            "sequence",
            "event_type",
            "event_id",
            "logical_date",
            "run_state",
            "operator_note",
        ]
        if reader.fieldnames != expected_header:
            fail("incident_timeline.csv header mismatch")
        events = list(reader)
    if len(events) != 14:
        fail("incident_timeline.csv must contain 14 events")
    if [row["sequence"] for row in events] != [str(value) for value in range(1, 15)]:
        fail("event sequence must be exactly 1..14")
    event_ids = [row["event_id"] for row in events]
    if len(set(event_ids)) != len(events) or any(not value for value in event_ids):
        fail("event_id must be non-empty and unique")
    dagruns = [row for row in events if row["event_type"] == "DAGRUN"]
    admin_events = [row for row in events if row["event_type"] == "ADMIN_UNPAUSE"]
    if len(dagruns) != 12 or len(admin_events) != 2:
        fail("timeline must contain 12 DAGRUN and 2 ADMIN_UNPAUSE rows")
    logical_dates: list[datetime] = []
    for row in dagruns:
        try:
            parsed = datetime.fromisoformat(row["logical_date"].replace("Z", "+00:00"))
        except ValueError as error:
            raise ValueError("invalid DAGRUN logical_date") from error
        if parsed.tzinfo is None or row["run_state"] not in {"success", "failed"}:
            fail("DAGRUN requires a timezone and a terminal run_state")
        logical_dates.append(parsed)
    if logical_dates != sorted(logical_dates) or len(set(logical_dates)) != len(logical_dates):
        fail("DAGRUN logical_date values must be unique and increasing")
    if any(row["logical_date"] or row["run_state"] for row in admin_events):
        fail("ADMIN_UNPAUSE must not carry logical_date or run_state")
    if any(not row["operator_note"].strip() for row in events):
        fail("operator_note must be populated")

    policy = json.loads((input_root / "pause_policy.json").read_text(encoding="utf-8"))
    fixed = {
        "version": "1.0",
        "dag_id": "moderation_feed_publish_guard",
        "schedule": "@daily",
        "catchup": False,
        "max_active_runs": 1,
        "is_paused_upon_creation": False,
        "run_type": "manual",
    }
    for key, expected in fixed.items():
        if policy.get(key) != expected:
            fail(f"pause_policy.json mismatch: {key}")
    threshold = policy.get("max_consecutive_failed_dag_runs")
    if type(threshold) is not int or not 2 <= threshold <= 6:
        fail("pause policy threshold must be an integer from 2 through 6")
    if policy.get("expected_tasks") != [
        "collect_review_decisions",
        "verify_policy_coverage",
        "publish_moderation_feed",
    ]:
        fail("pause_policy.json task list mismatch")
    if policy.get("expected_edges") != [
        ["collect_review_decisions", "verify_policy_coverage"],
        ["verify_policy_coverage", "publish_moderation_feed"],
    ]:
        fail("pause_policy.json edge list mismatch")

    starter_bag = DagBag(
        dag_folder=str(input_root / "starter" / "broken_moderation_feed.py"),
        include_examples=False,
        safe_mode=False,
    )
    if starter_bag.import_errors:
        raise RuntimeError(starter_bag.import_errors)
    starter = starter_bag.get_dag(policy["dag_id"])
    if starter is None or starter.max_consecutive_failed_dag_runs != 0:
        fail("starter does not expose the expected disabled threshold")
    starter_tasks, starter_edges = graph(starter)
    if starter_tasks != sorted(policy["expected_tasks"]):
        fail("starter task list mismatch")
    if starter_edges != sorted(tuple(edge) for edge in policy["expected_edges"]):
        fail("starter edge list mismatch")
    return policy, events


try:
    policy, events = read_and_validate_inputs()
    dagbag = DagBag(
        dag_folder=str(reference_root / "dags"),
        include_examples=False,
        safe_mode=False,
    )
    if dagbag.import_errors:
        raise RuntimeError(dagbag.import_errors)
    dag = dagbag.get_dag(policy["dag_id"])
    if dag is None:
        raise RuntimeError("repaired DAG not found")
    if dag.max_consecutive_failed_dag_runs != policy["max_consecutive_failed_dag_runs"]:
        fail("repaired DAG threshold does not match pause_policy.json")

    if stage_root.exists():
        shutil.rmtree(stage_root)
    stage_root.mkdir(parents=True)
    validation = replay(dag, policy, events, stage_root)
    if validation["result"] != "PASS":
        failed = [key for key, value in validation["checks"].items() if not value]
        raise RuntimeError("failed checks: " + ", ".join(failed))

    expected_outputs = {
        "event_ledger.csv",
        "dagrun_history.csv",
        "pause_log.csv",
        "dag_model_snapshot.json",
        "serialized_dag.json",
        "validation.json",
    }
    if {path.name for path in stage_root.iterdir()} != expected_outputs:
        raise RuntimeError("result file set mismatch")

    had_output = output_root.exists()
    if had_output:
        if backup_root.exists():
            shutil.rmtree(backup_root)
        output_root.rename(backup_root)
    try:
        stage_root.rename(output_root)
    except Exception:
        if had_output:
            backup_root.rename(output_root)
        raise
    if had_output:
        shutil.rmtree(backup_root)
    print(json.dumps(validation["controls"], ensure_ascii=False, sort_keys=True))
except Exception:
    if stage_root.exists():
        shutil.rmtree(stage_root)
    if backup_root.exists() and not output_root.exists():
        backup_root.rename(output_root)
    raise
