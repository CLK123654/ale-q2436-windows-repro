#内容审核Feed发布断路器演练

输入压缩包解压后必须得到`input_data/`。待修复的源文件是`input_data/starter/broken_moderation_feed.py`，修复后的DAG必须交付到`output/dags/moderation_feed_publish_guard.py`；两者是起点与成品，不是同一路径。

`pause_policy.json`规定DAG标识、调度方式、任务图和连续失败阈值。当前策略阈值为3，starter将其错误地设为0。`incident_timeline.csv`按sequence给出12次manual DagRun和2次管理员解封，所有数据均为离线构造，不含生产审核记录。

重放程序要把DAGRUN项写入新的Airflow元数据库，仅在终态为failed时调用Airflow2.10.5的`DagRun._check_last_n_dagruns_failed`。ADMIN_UNPAUSE项调用`DagModel.set_is_paused(False)`，不得删除、clear或改写已经写入的DagRun。

本题不启动scheduler进程。连续失败方法本身会向Airflow`Log`表写入`event=paused`、`owner=scheduler`、`owner_display_name=Scheduler`；这些字段是该方法在2.10.5中的固定检查值，不代表演练期间运行了Scheduler。`pause_log.csv`必须查询真实Log行，不能由导出脚本拼出同名字段。

输入保持只读。运行器校验文件集合、CSV结构、事件键、时间、终态和策略语义后，在临时目录生成结果，全部检查通过才替换`output/results/`。
